function removeCookie() {
	document.cookie = "session=-1";
}